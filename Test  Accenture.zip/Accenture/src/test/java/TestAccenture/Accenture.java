package TestAccenture;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Accenture {
	
	WebDriver driver;

	@Before
	public void setUp() throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://sampleapp.tricentis.com");
		driver.manage().timeouts().implicitlyWait(3000,TimeUnit.SECONDS);
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws InterruptedException {
		
		driver.findElement(By.name("Navigation Automobile")).click();
		driver.findElement(By.name("Make")).sendKeys("Ford");
		driver.findElement(By.name("[kW]")).sendKeys("2.0");
		driver.findElement(By.name("Open Date of Manufacture Calender")).click();
	    driver.findElement(By.name("Date of Manufacture")).sendKeys("09/07/2021");
		driver.findElement(By.id("numberofseats")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("numberofseats")).sendKeys("5");
		driver.findElement(By.id("numberofseats")).click();
		driver.findElement(By.id("fuel")).click();
		driver.findElement(By.id("fuel")).sendKeys("Petrol");
		driver.findElement(By.id("fuel")).click();
		driver.findElement(By.id("listprice")).sendKeys("65000");
		driver.findElement(By.name("License Plate Number")).sendKeys("6");
		driver.findElement(By.id("annualmileage")).sendKeys("22000");
		driver.findElement(By.id("nextenterinsurantdata")).click();
		driver.findElement(By.name("First Name")).sendKeys("Zulu");
		driver.findElement(By.id("lastname")).sendKeys("Carvalho");
		Thread.sleep(2000);
		driver.findElement(By.id("birthdate")).sendKeys("05/13/1985");
		driver.findElement(By.xpath("//*[@class='ideal-radiocheck-label']")).click();
		driver.findElement(By.name("Street Address")).sendKeys("Rua Holambra");
		driver.findElement(By.name("Country")).click();
		driver.findElement(By.name("Country")).sendKeys("Brazil");
		driver.findElement(By.name("Country")).click();
		driver.findElement(By.name("Zip Code")).sendKeys("1311");
		driver.findElement(By.id("city")).sendKeys("SP");
		driver.findElement(By.id("occupation")).click();
		driver.findElement(By.id("occupation")).sendKeys("Public Official");
		driver.findElement(By.xpath("//*[@class='ideal-check']")).click();
		driver.findElement(By.id("nextenterproductdata")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("startdate")).click();
		driver.findElement(By.id("startdate")).sendKeys("10/10/2021");
		driver.findElement(By.id("insurancesum")).click();
		driver.findElement(By.id("insurancesum")).sendKeys("3.000.000,00");
		driver.findElement(By.id("insurancesum")).click();
		driver.findElement(By.id("meritrating")).click();
		driver.findElement(By.id("meritrating")).sendKeys("Bonus 8");
		driver.findElement(By.id("meritrating")).click();
		driver.findElement(By.name("Damage Insurance")).click();
		driver.findElement(By.name("Damage Insurance")).sendKeys("Partial Coverage");
		driver.findElement(By.name("Damage Insurance")).click();
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//*[text()='Legal Defense Insurance']")).click();
	    driver.findElement(By.xpath("//*[text()='Euro Protection']")).click();
	    driver.findElement(By.name("Courtesy Car")).click();
	    driver.findElement(By.name("Courtesy Car")).sendKeys("Yes");
	    driver.findElement(By.name("Courtesy Car")).click();
	    driver.findElement(By.name("Next (Select Price Option)")).click();
	    driver.findElement(By.xpath("//*[@class='choosePrice ideal-radiocheck-label']")).click();
	    driver.findElement(By.id("nextsendquote")).click();
	    driver.findElement(By.name("E-Mail")).sendKeys("carol.fernanda@gmail.com");
	    driver.findElement(By.id("phone")).sendKeys("11980987790");
	    driver.findElement(By.id("username")).sendKeys("ZuluCarvalho");
	    driver.findElement(By.name("Password")).sendKeys("Jose13092021@");
	    driver.findElement(By.id("confirmpassword")).sendKeys("Jose13092021@");
	    driver.findElement(By.name("Comments")).sendKeys("�timo site para se realizar um cadastro para efetuar uma compra, ambiente muito seguro uso e recomendo! "
	    		+ " Parab�ns!! ");
	    driver.findElement(By.id("sendemail")).click();
	   
		
	  	
		
		
		
		
		
		
		
		
		
		
	
		
		

		
	}
	
	
}
